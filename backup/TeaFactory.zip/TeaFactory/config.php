<?php
// config.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'tea_factory_db');
define('DB_USER', 'root');
define('DB_PASS', '');
// BASE_URL should end without slash
define('BASE_URL', 'http://localhost/TeaFactory/public');

// session
session_start();
