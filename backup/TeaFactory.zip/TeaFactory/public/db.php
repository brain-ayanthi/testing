<?php
$conn = new mysqli('localhost', 'root', '', 'tea_factory_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>